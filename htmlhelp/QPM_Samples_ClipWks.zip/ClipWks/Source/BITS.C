/*******************************************************************************
* Program Id: bit.c
*    Version: 1.00
********************************************************************************
*
* Purpose: Sets the given bit in a passed bit string.  Returns the previous
*          value.  Be sure to pass the string by reference.  NOTE.  In order
*          to stay as fast as possible, minimal parameter checking is
*          performed.  It is up to the user to not be too stupid.
*
* Syntax:  bit( <OptC String>, <OptN (1...n) Offset> [, <OptL Set/Clear>] )
*
********************************************************************************/
#include <hbapi.h>

HB_FUNC(BIT  )
{
   unsigned char   mask,
                  *ptr;
   unsigned int    loc,
                   offset = hb_parni( 2 ) - 1,
                   res    = 0;

   loc = offset / 8;
   if ( loc < hb_parclen( 1 ) )
   {
      ptr = hb_parc( 1 ) + loc;
      loc = offset % 8;
      res = *ptr << loc & 0x80;

      if ( hb_pcount() > 2 )
      {
         mask = (unsigned char ) 0x80 >> loc;
         if ( hb_parl( 3 ) )
            *ptr = *ptr | mask;
         else
            *ptr = *ptr & ~mask;
      }
   }
   hb_retl( res );
}

#include "math.h"
#include "stddef.h"
#include <stdlib.h>
#include <stdio.h>


#ifndef HUGE_VAL
# define HUGE_VAL HUGE
#endif /*HUGE_VAL*/
//static void ConvertToIeeeExtended(double num, char *bytes);
static double ConvertFromIeeeExtended(unsigned char *bytes);
static double ConvertFromIeeeExtended1(unsigned char *bytes);
# define FloatToUnsigned(f) ((unsigned long)(((long)(f - 2147483648.0)) + 2147483647L) + 1)
HB_FUNC(L_DTOT1)
{
   double num = hb_parnd( 1 ) ;
   char bytes[10];
    int    sign;
    int expon;
    double fMant, fsMant;
    unsigned long hiMant, loMant;

    if (num < 0)
        {
        sign = 0x8000;
        num *= -1;
        }
    else
        {
        sign = 0;
        }
    if (num == 0)
        {
        expon = 0; hiMant = 0; loMant = 0;
        }
    else
        {
        fMant = frexp(num, &expon);
        if ((expon > 16384) || !(fMant < 1))
            {                                            /* Infinity or NaN */
            expon = sign|0x7FFF; hiMant = 0; loMant = 0; /* infinity */
            }
        else
            {                   /* Finite */
            expon += 16382;
            if (expon < 0)
                {               /* denormalized */
                fMant = ldexp(fMant, expon);
                expon = 0;
                }
            expon |= sign;
            fMant = ldexp(fMant, 32);          
            fsMant = floor(fMant); 
            hiMant = FloatToUnsigned(fsMant);
            fMant = ldexp(fMant - fsMant, 32); 
            fsMant = floor(fMant); 
            loMant = FloatToUnsigned(fsMant);
            }
        }
    bytes[0] = expon >> 8;
    bytes[1] = expon;
    bytes[2] = hiMant >> 24;
    bytes[3] = hiMant >> 16;
    bytes[4] = hiMant >> 8;
    bytes[5] = hiMant;
    bytes[6] = loMant >> 24;
    bytes[7] = loMant >> 16;
    bytes[8] = loMant >> 8;
    bytes[9] = loMant;


   hb_retclen(bytes,10);
}
HB_FUNC(L_DTOT)
{
   double num = hb_parnd( 1 ) ;
   char bytes[10];
    int    sign;
    int expon;
    double fMant, fsMant;
    unsigned long hiMant, loMant;

    if (num < 0)
        {
        sign = 0x8000;
        num *= -1;
        }
    else
        {
        sign = 0;
        }
    if (num == 0)
        {
        expon = 0; hiMant = 0; loMant = 0;
        }
    else
        {
        fMant = frexp(num, &expon);
        if ((expon > 16384) || !(fMant < 1))
            {                                            /* Infinity or NaN */
            expon = sign|0x7FFF; hiMant = 0; loMant = 0; /* infinity */
            }
        else
            {                   /* Finite */
            expon += 16382;
            if (expon < 0)
                {               /* denormalized */
                fMant = ldexp(fMant, expon);
                expon = 0;
                }
            expon |= sign;
            fMant = ldexp(fMant, 32);          
            fsMant = floor(fMant); 
            hiMant = FloatToUnsigned(fsMant);
            fMant = ldexp(fMant - fsMant, 32); 
            fsMant = floor(fMant); 
            loMant = FloatToUnsigned(fsMant);
            }
        }
    bytes[9] = expon >> 8;
    bytes[8] = expon;
    bytes[7] = hiMant >> 24;
    bytes[6] = hiMant >> 16;
    bytes[5] = hiMant >> 8;
    bytes[4] = hiMant;
    bytes[3] = loMant >> 24;
    bytes[2] = loMant >> 16;
    bytes[1] = loMant >> 8;
    bytes[0] = loMant;


   hb_retclen(bytes,10);
}



HB_FUNC( L_TTOD )
{
   char * szNum = hb_parc( 1 );
   hb_retnd( ConvertFromIeeeExtended1( szNum )) ;
}
#define UnsignedToFloat(u) (((double)((long)(u - 2147483647L - 1))) + 2147483648.0)

/*
    Extended precision IEEE floating-point conversion routine.
*/
static double ConvertFromIeeeExtended(unsigned char *bytes)
{
    double        f;
    int           expon;
    unsigned long hiMant, loMant;
    
    expon = ((bytes[0] & 0x7F) << 8) | (bytes[1] & 0xFF);
    hiMant  =  ((unsigned long)(bytes[2] & 0xFF) << 24)
            |  ((unsigned long)(bytes[3] & 0xFF) << 16)
            |  ((unsigned long)(bytes[4] & 0xFF) << 8)
            |  ((unsigned long)(bytes[5] & 0xFF));
    loMant  =  ((unsigned long)(bytes[6] & 0xFF) << 24)
            |  ((unsigned long)(bytes[7] & 0xFF) << 16)
            |  ((unsigned long)(bytes[8] & 0xFF) << 8)
            |  ((unsigned long)(bytes[9] & 0xFF));

    if (expon == 0 && hiMant == 0 && loMant == 0) {
        f = 0;
    }
    else {
        if (expon == 0x7FFF) {    /* Infinity or NaN */
            f = HUGE_VAL;
        }
        else {
            expon -= 16383;
            f  = ldexp(UnsignedToFloat(hiMant), expon-=31);
            f += ldexp(UnsignedToFloat(loMant), expon-=32);
        }
    }

    if (bytes[0] & 0x80)
        return -f;
    else
        return f;
}

static double ConvertFromIeeeExtended1(unsigned char *bytes)
{
    double        f;
    int           expon;
    unsigned long hiMant, loMant;
    
    expon = ((bytes[9] & 0x7F) << 8) | (bytes[8] & 0xFF);
    hiMant  =  ((unsigned long)(bytes[7] & 0xFF) << 24)
            |  ((unsigned long)(bytes[6] & 0xFF) << 16)
            |  ((unsigned long)(bytes[5] & 0xFF) << 8)
            |  ((unsigned long)(bytes[4] & 0xFF));
    loMant  =  ((unsigned long)(bytes[3] & 0xFF) << 24)
            |  ((unsigned long)(bytes[2] & 0xFF) << 16)
            |  ((unsigned long)(bytes[1] & 0xFF) << 8)
            |  ((unsigned long)(bytes[0] & 0xFF));

    if (expon == 0 && hiMant == 0 && loMant == 0) {
        f = 0;
    }
    else {
        if (expon == 0x7FFF) {    /* Infinity or NaN */
            f = HUGE_VAL;
        }
        else {
            expon -= 16383;
            f  = ldexp(UnsignedToFloat(hiMant), expon-=31);
            f += ldexp(UnsignedToFloat(loMant), expon-=32);
        }
    }

    if (bytes[0] & 0x80)
        return -f;
    else
        return f;
}

