
#ifndef __HB_COMM_H__
#define __HB_COMM_H__
#define HB_OS_WIN_32_USED
#include "hbapi.h"
#include "windows.h"
#ifdef __cplusplus
extern "C"
{
#endif

extern BOOL hb_init_port(char * Nx_port,unsigned int Nbaud,BYTE Ndata,BYTE Nparity, BYTE Nstop,DWORD nBufferSize);
extern void hb_unint_port( void );
extern void hb_outbufclr( void );
extern int  hb_outbufsize( void );
extern BOOL hb_isworking( void );
#ifdef __MINGW32__
extern BYTE * hb_inchr(DWORD nBytes);
#else
extern char * hb_inchr(DWORD nBytes); 
#endif
extern int  hb_inbufsize( void );
extern BOOL hb_outchr(char *szString);
#ifdef __cplusplus
}
#endif
#endif
