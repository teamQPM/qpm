#define HB_API_MACROS
#include "comm.h"
#include "hbcomm.h"
#include "stdio.h"
static  TCommPort Tcomm;
/*int main()
{
char *szBuffer;
hb_init_port("COM2",57600,8,NOPARITY,ONESTOPBIT,4000);
hb_outbufclr();
if (hb_isworking())
   printf(" a porta abriu\n");
else
   printf(" a porta n�o abriu\n");
   szBuffer= inchr(21);
hb_unint_port();
}
*/
BOOL hb_init_port(char * Nx_port,unsigned int Nbaud,BYTE Ndata,BYTE Nparity, BYTE Nstop,DWORD nBufferSize)
{
BOOL bReturn=TRUE;

Tcomm.SetCommPort( Nx_port);
try {
   Tcomm.OpenCommPort();
}
   catch(ECommError &e)  {
      if (e.Error == ECommError::OPEN_ERROR)
         bReturn=FALSE;
      }

Tcomm.SetBaudRate( Nbaud);
switch (Nparity) {
case 0:
   Tcomm.SetParity(NOPARITY);
   break;
case 1:
   Tcomm.SetParity(ODDPARITY);
   break;

case 2:
   Tcomm.SetParity(MARKPARITY);
   break;

case 3:
   Tcomm.SetParity(EVENPARITY);
   break;

}

Tcomm.SetByteSize(Ndata);

switch (Nstop) {
case 1 :
   Tcomm.SetStopBits(0);
   break;
case 2:
   Tcomm.SetStopBits(2);
   break;

default:
   Tcomm.SetStopBits(1);
   break;

}
Tcomm.dwBufferSize = nBufferSize;
return bReturn         ;
}

void hb_unint_port()
{
   Tcomm.CloseCommPort();
}

void hb_outbufclr()
{
   Tcomm.PurgeOCommPort();
}

BOOL hb_isworking()
{
   if (Tcomm.GetConnected())
      return TRUE;
   else
      return FALSE;
}

int hb_outbufsize()
{
return   Tcomm.BytesOAvailable();
}
int hb_inbufsize()
{
return   Tcomm.BytesAvailable();
}

#ifdef __MINGW32__
BYTE * hb_inchr(DWORD nBytes)
#else
char * hb_inchr(DWORD nBytes)
#endif
{
#ifdef __MINGW32__
BYTE *buffer = new BYTE[nBytes];
#else
char *buffer = new char[nBytes]; 
#endif
DWORD BytesRead = 0 ;

BytesRead = Tcomm.ReadBytes(buffer,nBytes);
   return buffer;

}

BOOL hb_outchr(char *szString)
{
   BOOL bReturn = FALSE;
   try {

      Tcomm.WriteString(szString);

   }

   catch(ECommError &e)  {
      if (e.Error == ECommError::WRITE_ERROR)
         bReturn=FALSE;
      }

   return bReturn;
}
