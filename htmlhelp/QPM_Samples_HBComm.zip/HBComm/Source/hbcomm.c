#define HB_API_MACROS
#include "hbapi.h"
#include "hbcomm.h"

HB_FUNC(INIT_PORT) /* Nx_port(string),Nbaud(numerico),Ndata(numerico),Nparity(numerico),Nstop(numerico),nBufferSize(numerico)
                   retorna .t. se abriu a porta */
{

        hb_retl( hb_init_port( hb_parc( 1 ) , hb_parnl( 2 ) ,
        hb_parnl( 3 ) , hb_parnl( 4 ) , hb_parnl( 5 ) ,
        hb_parnl( 6 ) ) );

}

HB_FUNC( OUTBUFCLR )
{

        hb_outbufclr()        ;

}

HB_FUNC( ISWORKING )
{

        hb_retl( hb_isworking() );

}

HB_FUNC( INCHR )  /* le x caracters da port */
{

        hb_retc( hb_inchr( hb_parnl( 1 ) ) );

}

HB_FUNC( OUTCHR ) /* Retorna .t. se escreveu ou .f. se n�o */
{

        hb_retl( hb_outchr( hb_parc( 1 ) ) );

}


HB_FUNC( INBUFSIZE )
{

        hb_retnl( hb_inbufsize() );

}

HB_FUNC( OUTBUFSIZE )
{

        hb_retnl( hb_outbufsize() );

}

HB_FUNC( UNINT_PORT )
{
   hb_unint_port();
}