/*
 * Harbour Project source code:
 * Socket C kernel
 *
 * Copyright 2001-2003 Matteo Baccan <baccan@infomedia.it>
 * www - http://www.harbour-project.org
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA (or visit the web site http://www.gnu.org/).
 *
 * As a special exception, the Harbour Project gives permission for
 * additional uses of the text contained in its release of Harbour.
 *
 * The exception is that, if you link the Harbour libraries with other
 * files to produce an executable, this does not by itself cause the
 * resulting executable to be covered by the GNU General Public License.
 * Your use of that executable is in no way restricted on account of
 * linking the Harbour library code into it.
 *
 * This exception does not however invalidate any other reasons why
 * the executable file might be covered by the GNU General Public License.
 *
 * This exception applies only to the code released by the Harbour
 * Project under the name Harbour.  If you copy code from other
 * Harbour Project or Free Software Foundation releases into a copy of
 * Harbour, as the General Public License permits, the exception does
 * not apply to the code that you add in this way.  To avoid misleading
 * anyone as to the status of such modified files, you must delete
 * this exception notice from them.
 *
 * If you write modifications of your own for Harbour, it is your choice
 * whether to permit this exception to apply to your modifications.
 * If you do not wish that, delete this exception notice.
 *
 */

#include <windows.h>

#include "hbapi.h"
#include "hbapiitm.h"
#include "hbapierr.h"

static WSADATA WSAData;
static int     bInit = FALSE;
// If startup fails no other functions are allowed
HB_FUNC( SOCKETINIT ) {
   if( WSAStartup( MAKEWORD(1, 1), &WSAData ) == 0 )
      bInit = TRUE;
}

HB_FUNC( SOCKETEXIT ) {
   if( bInit ) WSACleanup();
}

HB_FUNC( SOCKETCONNECT ){

   SOCKET m_hSocket = INVALID_SOCKET;
   if( bInit && ISCHAR( 2 ) && ISNUM( 3 ) ){
      int nPort;
      SOCKADDR_IN sockDestinationAddr;
      char * lpszAsciiDestination;

      lpszAsciiDestination = hb_parc(2);
      nPort = hb_parni(3);

      m_hSocket = socket(AF_INET, SOCK_STREAM, 0);
      if( m_hSocket != INVALID_SOCKET ){

         /* Determine if the address is in dotted notation */
         ZeroMemory(&sockDestinationAddr, sizeof(sockDestinationAddr));
         sockDestinationAddr.sin_family      = AF_INET;
         sockDestinationAddr.sin_port        = htons((u_short)nPort);
         sockDestinationAddr.sin_addr.s_addr = inet_addr(lpszAsciiDestination);

         /* if the address is not dotted notation, then do a DNS lookup of it */
         if (sockDestinationAddr.sin_addr.s_addr == INADDR_NONE) {
            LPHOSTENT lphost;
            lphost = gethostbyname(lpszAsciiDestination);
            if (lphost != NULL)
               sockDestinationAddr.sin_addr.s_addr = ((LPIN_ADDR)lphost->h_addr)->s_addr;
            else {
               hb_retl( FALSE );
               return;
            }
         }

         hb_retl( connect( m_hSocket,
                           (SOCKADDR*)&sockDestinationAddr,
                           sizeof(sockDestinationAddr) ) != SOCKET_ERROR );
      } else
         hb_retl( FALSE );
   } else
      hb_retl( FALSE );

   /* Copy m_hSocket to caller method */
   strncpy( hb_parc(1), (char*)&m_hSocket, sizeof(m_hSocket) );

}

HB_FUNC( SOCKETBIND ){

   SOCKET m_hSocket = INVALID_SOCKET;
   if( bInit && ISCHAR( 2 ) && ISNUM( 3 ) ){
      int nPort;
      SOCKADDR_IN sockDestinationAddr;
      char * lpszAsciiDestination;

      lpszAsciiDestination = hb_parc(2);
      nPort = hb_parni(3);

      m_hSocket = socket(AF_INET, SOCK_STREAM, 0);
      if( m_hSocket != INVALID_SOCKET ){

         /* Determine if the address is in dotted notation */
         ZeroMemory(&sockDestinationAddr, sizeof(sockDestinationAddr));
         sockDestinationAddr.sin_family      = AF_INET;
         sockDestinationAddr.sin_port        = htons((u_short)nPort);
         sockDestinationAddr.sin_addr.s_addr = inet_addr(lpszAsciiDestination);

         /* if the address is not dotted notation, then do a DNS lookup of it */
         if (sockDestinationAddr.sin_addr.s_addr == INADDR_NONE) {
            LPHOSTENT lphost;
            lphost = gethostbyname(lpszAsciiDestination);
            if (lphost != NULL)
               sockDestinationAddr.sin_addr.s_addr = ((LPIN_ADDR)lphost->h_addr)->s_addr;
            else {
               hb_retl( FALSE );
               return;
            }
         }

         hb_retl( bind( m_hSocket,
                           (SOCKADDR*)&sockDestinationAddr,
                           sizeof(sockDestinationAddr) ) != SOCKET_ERROR );
      } else
         hb_retl( FALSE );
   } else
      hb_retl( FALSE );

   /* Copy m_hSocket to caller method */
   strncpy( hb_parc(1), (char*)&m_hSocket, sizeof(m_hSocket) );

}

HB_FUNC( SOCKETLISTEN ){
   SOCKET m_hSocket  = INVALID_SOCKET;
   SOCKET sClient    = INVALID_SOCKET;
   SOCKADDR_IN remote_addr;

   /* Copy m_hSocket from caller method */
   strncpy( (char*)&m_hSocket, hb_parc(1), sizeof(m_hSocket) );

   if( bInit ){
      if( m_hSocket != INVALID_SOCKET ){
         int nRet = listen(m_hSocket, hb_parni(2) );        // Backlog 10
         if( nRet != SOCKET_ERROR ) {

            int iAddrLen = sizeof(remote_addr);
            sClient = accept(m_hSocket, (struct sockaddr *) &remote_addr, &iAddrLen);

	    // Error?
            if(sClient != SOCKET_ERROR) {
               hb_retl( TRUE );
            } else
               hb_retl( FALSE );
         } else 
            hb_retl( FALSE );
      } else
         hb_retl( FALSE );
   } else
      hb_retl( FALSE );

   /* Copy m_hSocket to caller method */
   strncpy( hb_parc(3), (char*)&sClient, sizeof(sClient) );
}

HB_FUNC( SOCKETSEND ){
   SOCKET m_hSocket = INVALID_SOCKET;

   /* Copy m_hSocket from caller method */
   strncpy( (char*)&m_hSocket, hb_parc(1), sizeof(m_hSocket) );

   if( bInit && ISCHAR( 2 ) ){
      if( m_hSocket != INVALID_SOCKET ){
         char *pszBuf = hb_parc(2);
         int nBuf = hb_parclen(2);
         if( ISNUM( 3 ) ){
            int sendtimeout = hb_parni(3);
            if( sendtimeout!=-1 )
               setsockopt(m_hSocket, SOL_SOCKET, SO_SNDTIMEO, (char *)&sendtimeout, sizeof(sendtimeout));
         }
         hb_retl( send(m_hSocket, pszBuf, nBuf, 0) != SOCKET_ERROR );
      } else
         hb_retl( FALSE );
   } else
      hb_retl( FALSE );

}

HB_FUNC( SOCKETRECEIVE ){
   SOCKET m_hSocket = INVALID_SOCKET;

   /* Copy m_hSocket from caller method */
   strncpy( (char*)&m_hSocket, hb_parc(1), sizeof(m_hSocket) );

   if( bInit && ISCHAR( 2 ) ){
      if( m_hSocket != INVALID_SOCKET ){
         char *pRead = hb_parc(2);
         int nLen = hb_parclen(2);
         if( ISNUM( 3 ) ){
            int recvtimeout = hb_parni(3);
            if( recvtimeout!=-1 )
               setsockopt(m_hSocket, SOL_SOCKET, SO_RCVTIMEO, (char *)&recvtimeout, sizeof(recvtimeout));
         }
         hb_retnl( recv(m_hSocket, pRead, nLen, 0) );
      } else
         hb_retnl( 0 );
   } else
      hb_retnl( 0 );
}

HB_FUNC( SOCKETCLOSE ){
   SOCKET m_hSocket = INVALID_SOCKET;

   /* Copy m_hSocket from caller method */
   strncpy( (char*)&m_hSocket, hb_parc(1), sizeof(m_hSocket) );

   if( bInit && m_hSocket != INVALID_SOCKET ){
      hb_retl( SOCKET_ERROR != closesocket(m_hSocket) );
   } else
      hb_retl( FALSE );

   m_hSocket = INVALID_SOCKET;

   /* Copy m_hSocket to caller method */
   strncpy( hb_parc(1), (char*)&m_hSocket, sizeof(m_hSocket) );
}

HB_FUNC( SOCKETLOCALNAME ){
   char ac[80];

   if( bInit && gethostname(ac, sizeof(ac)) != SOCKET_ERROR ) {
      hb_retc( ac );
   } else {
      hb_retc( "" );
   }
}

HB_FUNC( SOCKETLOCALADDRESS ){
   // int nRet=0;
   char ac[80];

   if( bInit && gethostname(ac, sizeof(ac)) != SOCKET_ERROR ) {
      struct hostent *phe = gethostbyname(ac);
      if( phe != 0 ){
         int i=0;
         while( phe->h_addr_list[i]!=0 ) i++;

         hb_reta( i );

         for( i=0; phe->h_addr_list[i] != 0; ++i) {
            struct in_addr addr;
            memcpy(&addr, phe->h_addr_list[i], sizeof(struct in_addr));
            hb_storc( inet_ntoa(addr), -1, i+1 );
         }

      } else
         hb_reta( 0 );
   } else
      hb_reta( 0 );
}
