1.- Renombrar el QAC.EXE de nuestra instalacion QAC.EXE.4.12.0

2.- Descomprimir el archivo zip en un directorio temporal

3.- Copiar el QAC.EXE del directorio temporal en el directorio de nuestra instalacion QAC

Vuelta atr�s:

1.- Eliminar el QAC.EXE de nuestra instalacion de QAC

2.- Renombrar QAC.EXE.4.12.0 como QAC.EXE