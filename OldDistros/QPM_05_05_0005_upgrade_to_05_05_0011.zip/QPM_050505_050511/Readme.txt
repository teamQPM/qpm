/*
 * $Id: UpgradeReadme.txt 101 2015-03-04 22:59:14Z fyurisich $
 */



HOW TO INSTALL THIS UPGRADE
===========================

[1] In the current instalation folder, rename file QPM.EXE to QPM.EXE.OLD
[2] Copy the new QPM.EXE file to the current installation folder.


HOW TO UNINSTALL THIS UPGRADE
=============================

[1] Delete the file QPM.EXE
[2] Rename QPM.EXE.OLD to QPM.EXE



COMO INSTALAR ESTE UPGRADE
==========================

[1] En la carpeta de instalaci�n actual, renombre el archivo QPM.EXE
    como QPM.EXE.OLD
[2] Copie el nuevo QPM.EXE a la carpeta de instalaci�n actual.


COMO DESINSTALAR ESTE UPGRADE
=============================

[1] Borre el archivo QPM.EXE
[2] Renombre el archivo QPM.EXE.OLD como QPM.EXE



COMO INSTALAR ESSE UPGRADE
==========================

[1] Na pasta de instala��o atual, renomeie o arquivo QPM.EXE
    como QPM.EXE.OLD
[2] Copie o novo QPM.EXE a pasta de instala��o atual.


COMO REMOVER ESSE UPGRADE
=========================

[1] Exclua o arquivo QPM.EXE
[2] Renomeie o arquivo QPM.EXE.OLD como QPM.EXE
